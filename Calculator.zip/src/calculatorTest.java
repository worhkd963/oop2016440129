
public class calculatorTest {

	public static void main(String[] args) {
		calculator ca = new calculator();

	}

}
